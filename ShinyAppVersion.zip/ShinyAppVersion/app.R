## app.R

## Install once if needed (run manually, not inside the app):
## install.packages("shiny")
## install.packages("DT")

library(shiny)
options(shiny.maxRequestSize = 2000 * 1024^2)   # 200 MB limit – adjust as needed
library(DT)

## Load your core LigandScanner code
source("ligandscanner_core.R")

ui <- fluidPage(
  titlePanel("LigandScanner Shiny (v0)"),
  
  sidebarLayout(
    sidebarPanel(
      fileInput(
        "mgf_file",
        "Upload MGF file",
        accept = c(".mgf")
      ),
      
      numericInput(
        "frag_tol",
        "Fragment tolerance (Da)",
        value = 0.01,
        min = 0.0001,
        max = 1,
        step = 0.001
      ),
      
      numericInput(
        "min_mass",
        "Minimum mass shift (Da)",
        value = 40,
        min = -200,
        max = 2000,
        step = 1
      ),
      
      numericInput(
        "min_frag",
        "Minimum number of reporter ions",
        value = 8,
        min = 1,
        max = 50,
        step = 1
      ),
      
      actionButton("run", "Run LigandScanner")
    ),
    
    mainPanel(
      h4("Results (absolute intensities)"),
      DTOutput("results_table"),
      br(),
      downloadButton("download_csv", "Download results as CSV")
    )
  )
)

server <- function(input, output, session) {
  
  ## Run LigandScanner when button is clicked
  results <- eventReactive(input$run, {
    req(input$mgf_file)
    
    withProgress(message = "Running LigandScanner...", value = 0, {
      mgf_path <- input$mgf_file$datapath
      
      res_list <- ligandscanner_run(
        mgf_path        = mgf_path,
        frag_tol_da     = input$frag_tol,
        min_mass_shift  = input$min_mass,
        min_frag_number = input$min_frag
      )
      
      incProgress(1)
      
      ## For now we show the absolute matrix
      validate(
        need(
          is.data.frame(res_list$absolute) && nrow(res_list$absolute) > 0,
          "No hits after filtering. Try relaxing thresholds."
        )
      )
      
      res_list$absolute
    })
  })
  
  ## Show results table
  output$results_table <- renderDT({
    req(results())
    datatable(results(), options = list(pageLength = 25))
  })
  
  ## Download handler
  output$download_csv <- downloadHandler(
    filename = function() {
      paste0("LigandScanner_results_", Sys.Date(), ".csv")
    },
    content = function(file) {
      write.csv(results(), file, row.names = FALSE)
    }
  )
}

shinyApp(ui, server)
