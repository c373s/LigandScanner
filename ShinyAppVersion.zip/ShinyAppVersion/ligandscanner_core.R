## ligandscanner_core.R

## Load required libraries (install them once manually, not in this file!)
library(MSnbase)
library(RforProteomics)

## expected fragment m/z values
expected_fragments <- c(
  523.942589, 785.410246,
  518.267073, 776.896971,
  755.383499, 626.340906,
  529.288142, 373.187031,
  302.149918, 205.097154,
  378.195388, 313.674091,
  265.147709, 187.097154,
  151.578597, 103.052215,
  116.034219, 203.066248,
  302.134661, 403.18234,
  559.283451, 687.342029
)

## Helper: compute IonCheck matrices for a given MSnExp object
MGF_to_IONcheck <- function(Wt, frag_tol_da = 0.01) {
  FragTol <- frag_tol_da^2
  
  IonCheck <- matrix(nrow = length(Wt), ncol = 31)
  IonCheck_Absolute <- matrix(nrow = length(Wt), ncol = 31)
  
  colnames(IonCheck) <- c(
    "p3+", "p2+","p3+ -NH2", "p2+ -NH2",
    "y6", "y5", "y4", "y3", "y2", "y1",
    "y6+2", "y5+2", "y4+2", "y3+2", "y2+2", "y1+2",
    "b1", "b2", "b3", "b4", "b5", "b6",
    "SpectrumNr", "#Fragments", "RetentionTime", "Precursor_mz",
    "Charge", "Delta_Mass", "Delta_Mass_Oxygen", "Fragment_Sum",
    "Fragment_Contribution"
  )
  
  colnames(IonCheck_Absolute) <- c(
    "p3+", "p2+","p3+ -NH2", "p2+ -NH2",
    "y6", "y5", "y4", "y3", "y2", "y1",
    "y6+2", "y5+2", "y4+2", "y3+2", "y2+2", "y1+2",
    "b1", "b2", "b3", "b4", "b5", "b6",
    "SpectrumNr", "#Fragments", "RetentionTime", "Precursor_mz",
    "Charge", "Delta_Mass", "Delta_Mass_Oxygen", "Base_Peak", "TIC"
  )
  
  ## Loop over spectra
  for (SpectrumCount in seq_along(Wt)) {
    
    ## >>> added: simple console progress every 200 spectra
    if (SpectrumCount %% 50 == 0 || SpectrumCount == length(Wt)) {
      message(
        "Processed ", SpectrumCount, " / ", length(Wt), " spectra..."
      )
    }
    ## <<<
    
    MSMS_tempp <- Wt[[SpectrumCount]]
    MSMS_mz <- MSMS_tempp@mz
    Intensity_temp <- MSMS_tempp@intensity
    
    ## Loop over expected fragments
    for (fragment_count in seq_along(expected_fragments)) {
      diff_vec <- MSMS_mz - expected_fragments[fragment_count]
      diff_sq <- diff_vec * diff_vec
      
      if (min(diff_sq) <= FragTol) {
        idx <- which.min(diff_sq)
        IonCheck[SpectrumCount, fragment_count] <-
          Intensity_temp[idx] / max(Intensity_temp)
        IonCheck_Absolute[SpectrumCount, fragment_count] <-
          Intensity_temp[idx]
      } else {
        IonCheck[SpectrumCount, fragment_count] <- 0
        IonCheck_Absolute[SpectrumCount, fragment_count] <- 0
      }
    }
    
    ## Base peak and TIC
    IonCheck_Absolute[SpectrumCount, 30] <- max(Intensity_temp)
    IonCheck_Absolute[SpectrumCount, 31] <- sum(Intensity_temp)
  }
  
  ## Add metadata columns
  for (j in seq_along(Wt)) {
    MSMS_tempp <- Wt[[j]]
    
    IonCheck[j, 23] <- j
    IonCheck_Absolute[j, 23] <- j
    
    IonCheck[j, 24] <- sum(IonCheck[j, 1:22] != 0)
    IonCheck_Absolute[j, 24] <- sum(IonCheck[j, 1:22] != 0)
    
    IonCheck[j, 25] <- MSMS_tempp@rt
    IonCheck_Absolute[j, 25] <- MSMS_tempp@rt
    
    IonCheck[j, 26] <- MSMS_tempp@precursorMz
    IonCheck_Absolute[j, 26] <- MSMS_tempp@precursorMz
    
    IonCheck[j, 27] <- MSMS_tempp@precursorCharge
    IonCheck_Absolute[j, 27] <- MSMS_tempp@precursorCharge
    
    ## Delta mass and +O variant
    dm <- IonCheck[j, 26] * IonCheck[j, 27] -
      IonCheck[j, 27] * 1.0072764 - 1568.8059
    
    IonCheck[j, 28] <- dm
    IonCheck_Absolute[j, 28] <- dm
    
    IonCheck[j, 29] <- dm + 15.99491463
    IonCheck_Absolute[j, 29] <- dm + 15.99491463
  }
  
  list(
    IonCheck = IonCheck,
    IonCheck_Absolute = IonCheck_Absolute
  )
}

## Main function: this is what Shiny will call
ligandscanner_run <- function(
    mgf_path,
    frag_tol_da = 0.01,
    min_mass_shift = 40,
    min_frag_number = 8
) {
  
  message("Starting ligandscanner_run()")
  message("Reading MGF file: ", mgf_path)
  
  t_start <- Sys.time()
  
  ## Read MGF
  MR1_data <- readMgfData(
    filename   = mgf_path,
    pdata      = NULL,
    centroided = TRUE,
    smoothed   = FALSE,
    verbose    = FALSE,
    cache      = 1
  )
  
  t_read <- Sys.time()
  message(
    "Finished readMgfData(): ",
    length(MR1_data), " spectra loaded in ",
    round(difftime(t_read, t_start, units = "secs")), " seconds."
  )
  
  message("Computing IonCheck matrices...")
  
  ## Compute IonCheck matrices
  ion_list <- MGF_to_IONcheck(MR1_data, frag_tol_da = frag_tol_da)
  
  message("Applying filters...")
  
  IonCheck_bin <- ion_list$IonCheck
  IonCheck_abs <- ion_list$IonCheck_Absolute
  
  ## Apply filters
  keep_bin <- IonCheck_bin[, 28] >= min_mass_shift &
    IonCheck_bin[, 24] >= min_frag_number
  keep_abs <- IonCheck_abs[, 28] >= min_mass_shift &
    IonCheck_abs[, 24] >= min_frag_number
  
  IonCheck_bin_filt <- as.data.frame(IonCheck_bin[keep_bin, , drop = FALSE])
  IonCheck_abs_filt <- as.data.frame(IonCheck_abs[keep_abs, , drop = FALSE])
  
  message(
    "Filtering done. ",
    nrow(IonCheck_abs_filt), " spectra remain (absolute), ",
    nrow(IonCheck_bin_filt), " spectra remain (binary)."
  )
  
  ## Return as a list; Shiny can pick which to show
  list(
    binary   = IonCheck_bin_filt,
    absolute = IonCheck_abs_filt
  )
}
